export const container: string;
