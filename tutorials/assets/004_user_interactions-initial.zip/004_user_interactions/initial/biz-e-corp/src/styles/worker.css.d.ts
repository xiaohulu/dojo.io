export const worker: string;
export const image: string;
